import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path
from fontTools.pens.recordingPen import RecordingPen
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont


def glyph_recordings(ttf):
    glyph_set = ttf.getGlyphSet()
    recordings = {}
    for name in ttf.getGlyphOrder():
        pen = RecordingPen()
        glyph_set[name].draw(pen)
        recordings[name] = tuple(pen.value)
    return recordings

parser = argparse.ArgumentParser()
parser.add_argument("request")
parser.add_argument("output")
args = parser.parse_args()
request = json.loads(Path(args.request).read_text())
out = Path(args.output)
out.mkdir(parents=True, exist_ok=True)
prefix = request.get("prefix", "WebPSD")
assert re.fullmatch(r"[A-Za-z][A-Za-z0-9-]{0,30}", prefix), "Invalid font prefix"
result = []
seen_names = {}

for entry in request["fonts"]:
    source = Path(entry["source"])
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    font = TTFont(source, fontNumber=entry.get("index", 0))
    weight = int(entry.get("weight") or font["OS/2"].usWeightClass)
    was_variable = "fvar" in font
    if was_variable:
        axes = {axis.axisTag: axis.defaultValue for axis in font["fvar"].axes}
        if "wght" in axes:
            axes["wght"] = weight
        font = instantiateVariableFont(font, axes, inplace=False)
    if not entry.get("allowWeightFallback") and font["OS/2"].usWeightClass != weight:
        raise ValueError(f"Font weight does not match manifest: {source}")
    weight = font["OS/2"].usWeightClass
    baseline_tables = {tag: font.getTableData(tag) for tag in ["glyf", "CFF ", "CFF2", "hmtx"] if tag in font}
    baseline_cmap = dict(font.getBestCmap())
    original_name = font["name"].getDebugName(6)
    italic = bool(font["head"].macStyle & 2)
    license_text = "\n".join(filter(None, [font["name"].getDebugName(13), font["name"].getDebugName(14)]))
    if request.get("rename"):
        style = {400: "Regular", 700: "Bold"}.get(weight, f"Weight{weight}") + ("Italic" if italic else "")
        family = f"{prefix}-{digest[:8]}-{entry.get('index', 0)}"
        postscript = f"{family}-{style}"
        new_names = {
            1: family, 2: style, 3: postscript, 4: f"{family} {style}",
            6: postscript, 16: family, 17: style,
        }
        font["name"].names = [n for n in font["name"].names if n.nameID not in new_names]
        for name_id, value in new_names.items():
            font["name"].setName(value, name_id, 3, 1, 0x409)
            font["name"].setName(value, name_id, 1, 0, 0)
        font["OS/2"].fsSelection &= ~(0x20 | 0x40)
        font["OS/2"].fsSelection |= 0x20 if weight >= 700 else (0 if italic else 0x40)
        font["head"].macStyle = (font["head"].macStyle & ~1) | int(weight >= 700)
    else:
        postscript = original_name
    identity = (digest, entry.get("index", 0), weight)
    if not postscript or (postscript in seen_names and seen_names[postscript] != identity):
        raise ValueError("Duplicate/missing PostScript font name. Use --rename-fonts only for fonts you may modify.")
    seen_names[postscript] = identity
    suffix = f"-{entry.get('index', 0)}-{weight}"
    filename = f"{digest[:16]}{suffix}.ttf" if "glyf" in font else f"{digest[:16]}{suffix}.otf"
    target = out / filename
    if request.get("rename") or font.flavor or was_variable or source.suffix.lower() in [".ttc", ".otc"]:
        font.flavor = None
        font.save(target)
    else:
        shutil.copyfile(source, target)
    exported = TTFont(target)
    for tag, original in baseline_tables.items():
        if original == exported.getTableData(tag):
            continue
        if tag in ("CFF ", "CFF2"):
            # fontTools re-serializes CFF on save, so byte equality is not
            # expected; compare glyph outlines semantically instead.
            assert glyph_recordings(font) == glyph_recordings(exported), \
                f"Font outlines changed: {tag}"
            continue
        raise AssertionError(f"Font table changed: {tag}")
    assert baseline_cmap == exported.getBestCmap(), "Unicode character mapping changed"
    result.append({
        "id": entry["id"], "browserFamily": entry.get("browserFamily", f"UniFlex-{digest[:16]}"),
        "weight": weight, "postscriptName": postscript,
        "italic": italic, "instantiatedVariableFont": was_variable,
        "license": license_text or "License not present in font metadata; verify redistribution rights.",
        "sourceURL": entry.get("sourceURL"),
        "platformPostscriptName": entry.get("platformPostscriptName", original_name),
        "originalPostscriptName": original_name,
        "filename": f"fonts/{filename}", "sourceSha256": digest,
        "exportSha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "codepoints": sorted(exported.getBestCmap()),
    })

(out / "manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"Prepared {len(result)} fonts; source outlines/metrics/cmap unchanged.")
