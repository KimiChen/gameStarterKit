import argparse
import json
from collections import Counter
from pathlib import Path
import numpy as np
from PIL import Image
from psd_tools import PSDImage

parser = argparse.ArgumentParser()
parser.add_argument("directory")
args = parser.parse_args()
root = Path(args.directory).resolve()
report = json.loads((root / "validation.json").read_text())
psd_path = (root / report["psd"]).resolve()
if psd_path.parent != root:
    raise ValueError("PSD path escapes output directory")
psd = PSDImage.open(psd_path)
layers = list(psd.descendants())
types = [layer for layer in layers if layer.kind == "type"]
# Instance text that differs from the component file is an #override layer.
# The page text inventory counts captured text, not those extra layers.
structural = [layer for layer in types if not (layer.name and "#override]" in layer.name)]
inventory = json.loads((root / "text-inventory.json").read_text())
assert psd.size == (report["width"], report["height"])
assert len(types) == report["textLayers"]
assert len(structural) == len(inventory)
assert Counter(layer.text.rstrip("\x00\r").replace("\r", "\n") for layer in structural) == Counter(item["text"] for item in inventory)
assert sum(layer.is_group() for layer in layers) == report["groups"]
independent = psd.composite(ignore_preview=True)
independent.save(root / "independent-preview.png")
reference = Image.open(root / "web-reference.png").convert("RGBA")
assert independent.size == reference.size
delta = np.abs(np.asarray(independent.convert("RGBA"), dtype=np.int16) - np.asarray(reference, dtype=np.int16))
metrics = {
    "meanAbsoluteRgbError": float(delta[:, :, :3].mean()),
    "meanAbsoluteAlphaError": float(delta[:, :, 3].mean()),
    "differentPixelPercent": float((delta.max(axis=2) > 25).mean() * 100),
}
limits = report["limits"]
assert metrics["meanAbsoluteRgbError"] <= limits["maxMeanError"], metrics
assert metrics["meanAbsoluteAlphaError"] <= limits.get("maxAlphaError", limits["maxMeanError"]), metrics
assert metrics["differentPixelPercent"] <= limits["maxDifferentPixelPercent"], metrics
report["independentVerification"] = {
    "reader": "psd-tools", "passed": True, "typeLayers": len(types), **metrics,
}
(root / "validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(f"Independent PSD validation passed: {len(types)} Type layers; {metrics}")
