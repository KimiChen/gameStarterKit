# web-ui-to-psd

将 UniFlex 或常规 DOM 网页导出为带真实文字层的分层 PSD。独立工具，不修改网页项目，不要求拥有项目源码。

同时提供本地操作页面和 CLI；操作页面以隔离子进程调用同一 CLI，不维护第二套转换实现。

## 安装

需要 Node.js >= 22、`uv` 和 Chrome。在工具目录执行 `npm ci`。

首次运行会通过 `uv` 联网准备字体处理、PSD 独立验证所需的 Python 依赖。默认使用系统 Chrome；没有 Chrome 时运行 `npx playwright install chromium`，在配置中将 `channel` 设为 `null`。

## 操作页面

```bash
npm run workbench
# 默认 http://127.0.0.1:4320/

# 指定端口、结果目录，并载入已有公共配置
node bin/cli.mjs serve --port 4321 --data-root output/workbench \
  --config output/common-config-v4/config.json
```

- **网页导出**：输入 URL，选择公共配置或不使用配置；调整视口与根选择器，分析公共资源、采集预览、导出 PSD。完成后查看网页/PSD 对照、图层、验证、警告，下载 PSD/ZIP。
- **PSD 转 UniFlex**：上传普通 PSD，生成可编辑的中间设计文件及真实 UniFlex Web 页面，查看 PSD/Web 对照、转换警告，下载中间工程或打开页面。不要求 PSD 带有 Octane ID。
- **Octane 工程**：连接本机 Octane 开发工作台，导出其原生可回写 PSD；上传编辑后的 PSD，查看逐项差异，再明确选择应用。
- 原生 PSD 导入只是预览，不自动改工程；冲突默认不选择，颜色解释等确认项必须显式确认。报告有错误不能提交。
- 任务串行执行，支持排队、日志、取消和历史结果；每项任务提供对应 CLI 命令。运行中的设计提交不能取消，关闭工作台会等待它返回。
- 结果保存在 `--data-root/jobs/<id>/result/`，上传文件保存在 `uploads/`。重启后恢复已完成历史和公共配置；中断任务标记失败，不自动重跑。已开始但结果不确定的回写禁止使用同份报告重试，必须先核对工程版本再重新导入。文件含页面内容和字体，应按项目权限保管。
- 仅监听 `127.0.0.1`，检查 Host/Origin 和写操作 token，不提供公网部署或多人权限系统。默认每次最多排队 8 项，任务超时 10 分钟；只分析有权访问的 URL。

网页导出产物不具有 Octane 原生回写契约，不能通过导入操作反向修改任意网站。原生模式仍受 Octane 的固定节点、字体登记、ICC 和版本约束。

## PSD → UniFlex

### 上传触发的 CI 预览

这条路径用于自动生成美术预览，不需要人工选择组件修改，也不会自动写回项目源码或批准美术稿：

```text
PSD 上传/存储事件
  -> CI 将 PSD 下载到 runner
  -> ci-preview 导入并构建页面
  -> 发布到独立版本目录
  -> 浏览器打开发布地址，确认加载本次设计
  -> CI 读取 previewUrl，回填到上传记录/消息通知
```

提供的是平台无关执行入口；上传事件、runner 调度、通知和线上静态服务器需要由所在平台配置，
本工具不会隐式创建 CI 平台任务。runner 需要 Node >=22、已安装的工具依赖、uv、Chrome、
真实 UniFlex frontend 源码和已获授权的字体目录。

```bash
node bin/cli.mjs ci-preview \
  --file /ci/input/artwork.psd --font-dir /ci/fonts \
  --uniflex-root /ci/uniflex/frontend \
  --out /ci/private-artifacts/job-123 \
  --publish-root /mnt/preview-webroot \
  --public-base-url https://preview.example.test/ui/ \
  --preview-id job-123
```

静态服务器必须已将 `https://preview.example.test/ui/` 映射到 `/mnt/preview-webroot/`，
例如 runner 挂载该 webroot 的共享存储。地址应可被 runner 和美术访问；需要登录的内网预览，
应在服务器/网络层配置访问控制，当前命令不提供浏览器登录凭据。不要直接暴露工作台上传接口到公网。

成功时私有产物内的 `ci-preview.json` 返回：

```json
{
  "status": "published",
  "previewUrl": "https://preview.example.test/ui/job-123/index.html",
  "urlVerified": true,
  "reviewStatus": "not-approved",
  "projectSourceModified": false
}
```

- `--out` 存放私有中间设计、补充信息、报告和 `site/`，不可与发布根目录重叠。
- 公开版本目录仅复制页面代码、必要设计数据、实际使用的图片/字体及授权说明，不发布原 PSD、
  `psd-extra.json`、导出基线、无用嵌入二进制、运行时源码来源报告。
- 发布成功后用浏览器实际渲染并核对设计数据，不以 HTTP 200 代替页面可用性。
  这不是 PSD 像素验收或业务交互验证，转换警告保存在私有报告。
- 不传 `--publish-root/--public-base-url` 时只构建产物，状态为 `built`、`previewUrl:null`，
  可交给平台自有发布步骤；两项发布参数必须一起传。
- 默认生成随机版本 ID；显式 ID 限 ASCII 字母数字、`_`、`-`，已有版本拒绝覆盖。
  重试使用新版本 ID；清理和保留期限由 CI/存储平台配置。
- 发布后的地址检查失败时退出 1，报告为 `published-url-check-failed`，`previewUrl` 仍为 null；
  已复制的独立版本保留用于排错，不自动删除或覆盖。请修复映射后用新版本重跑。
- 美术资源和字体仍受项目权限、分发许可约束；预览地址不是授权机制。

已有 CI 可直接执行平台无关脚本：

```bash
export PSD_FILE=/ci/input/artwork.psd
export CI_ARTIFACT_DIR=/ci/private-artifacts/job-123
export PREVIEW_ROOT=/mnt/preview-webroot
export PREVIEW_BASE_URL=https://preview.example.test/ui/
export PREVIEW_ID=job-123
export UNIFLEX_ROOT=/ci/uniflex/frontend
export FONT_DIR=/ci/fonts
bash scripts/ci-psd-preview.sh
```

脚本成功后输出 `PREVIEW_URL=...`，同时保留结构化 `ci-preview.json` 供 CI 回填链接。
预览页面不依赖 CI runner 持续运行，只依赖配置的静态服务器及已发布目录。

### UniFlex 主链 CLI

在工具目录执行。项目页面需要提供 `__UNIFLEX_DESIGN_SNAPSHOT__`；组件归属来自项目显式声明，
不按 PSD 组名猜测组件。以下流程不调用模型。

```bash
# 一条命令：实时 Web -> 分层 PSD -> 导入 -> UniFlex Web -> 原始 Web 截图验收
node bin/cli.mjs uniflex-roundtrip \
  --url 'http://127.0.0.1:8000/?ui=prompt' --selector '#ui' \
  --width 750 --height 1624 --out output/prompt-roundtrip

# 对已有的未编辑往返结果重新截图验收
node bin/cli.mjs uniflex-verify \
  --export output/prompt-roundtrip/export --web output/prompt-roundtrip/web

# 编辑 PSD 后，使用随原导出交付的真实字体重新导入
node bin/cli.mjs psd-to-web --file edited.psd \
  --font-dir output/prompt-roundtrip/export/fonts --out output/edited-web

# 生成组件修改提案；默认读取 after/component-declarations.json
node bin/cli.mjs uniflex-reconcile \
  --before output/prompt-roundtrip/web --after output/edited-web --out output/proposal

# 审阅提案后，在选择文件中填写字段 ID 并明确 approved:true，再应用到新目录
node bin/cli.mjs uniflex-apply \
  --before output/prompt-roundtrip/web --after output/edited-web \
  --proposal output/proposal/component-proposal.json \
  --selection output/proposal/selection.template.json --out output/approved-web

node bin/cli.mjs preview-web --design output/approved-web/design.json --port 4322
```

另一台机器构建 Web 时需要指定 `--uniflex-root /path/to/uniflex/frontend`；
`uniflex-roundtrip`、`uniflex-apply` 和原来的 Web 构建命令均支持此参数。
`uniflex-roundtrip` 也支持公共资源 `--config`，且不允许跳过独立 PSD 验证。

选择模板默认 `approved:false`、`selected:[]`，不会自动批准。`proposalSha256` 已填写，
原样保留；`selected` 中填写提案实际包含的 `图层ID.字段`，例如 `layer-23.text`。
当前可应用字段为 `text`、`worldFrame`、`visible`、`opacity`。位置使用画布坐标，
选择父组的位置不隐式移动未选择的子节点；整组平移时应同时选中有关子层的位置修改。
前后设计、声明、提案或选择摘要不匹配时拒绝应用，必须重新生成并审阅。

输出与退出码：

- 往返目录含 `export/`、`web/`、`roundtrip-validation.json`；以最初 Web 截图为独立对照，
  检查画布、图层身份/类型/父子顺序/文字和像素；不做非等比缩放。当前是全图阈值，非区块验收。
- 提案目录含 `component-proposal.json` 和未批准的 `selection.template.json`。
  声明文件也保存在 PSD XMP 中，可由导入器恢复，额外声明可使用 `--contract` 指定。
- 应用目录含新设计、资源、Web、截图和 `application.json`；不写回项目 TSX 或业务代码。
  应用后的像素验收仍需要适用的独立 Golden，不把旧 PSD 合成图当成编辑后证据。
- 退出 `0` 表示该命令完成并满足其检查；冲突或视觉/结构验收不通过退出 `1`，保留明确标记失败的诊断。
  执行异常则不发布半成品目录。输出目录已有内容时拒绝覆盖；`verify` 类命令例外，会刷新原目录中的验收证据。

`uniflex-roundtrip` 验证的是**未编辑展示往返**，不能证明任意 PSD 无损往返、Photoshop 原生编辑、
原始组件源码或 `onAction` 业务绑定恢复。`uniflex-verify` 不应用于有意改字后的设计与旧源图比较。
历史 `scripts/reconcile-uniflex-components.mjs`、`scripts/apply-uniflex-components.mjs`、
`scripts/verify-uniflex-roundtrip.mjs` 仅为主 CLI 的兼容转发入口，不再维护独立实现。
操作页面尚未接入 UniFlex 提案审批；当前新增流程通过 CLI 使用。

### 分步导入

```bash
# 一步导入与构建，font-dir 可选；缺少精确字体时明确降级为图片
node bin/cli.mjs psd-to-web --file artwork.psd --font-dir /path/to/fonts \
  --uniflex-root /path/to/uniflex/frontend --out output/imported-web

# 分开执行：生成中间文件，然后修改 design.json 再构建
node bin/cli.mjs psd-import --file artwork.psd --font-dir /path/to/fonts \
  --out output/imported-design
node bin/cli.mjs uniflex-build --design output/imported-design/design.json \
  --uniflex-root /path/to/uniflex/frontend --out output/rebuilt-web

# 独立打开已生成的页面，无需原站点服务
node bin/cli.mjs preview-web --design output/rebuilt-web/design.json --port 4322
```

构建需要真实 UniFlex `frontend` 源码，当前机器默认 `/Volumes/wx/client/pinball/frontend`；另一台机器传 `--uniflex-root`。不修改源码、不包含 Game 业务代码，也不是仿写 DOM 渲染器。生成页面用 HTTP 静态服务器打开，不支持直接双击 `file://`。构建和日常转换不调用模型。

`uniflex-package` 会按 PSD 顶层组拆分 UniFlex `defineComponent`，组合为一个 `defineView` 页面。
名称中包含“使用、领取、返回、关闭、分页、页签”等语义的节点会生成 `interaction="press"`，
并通过 `<Name>Action` 的 `onAction` 回调输出 `primary`、`back`、`close`、`tab` 或 `select` 动作；
页面同时保留本地选中态反馈。它不会凭 PSD 推断库存、导航或服务器命令，这些由项目业务代码绑定。

工作台使用 `serve --uniflex-root ... --font-dir ...` 配置源码和字体目录。没有显式字体目录时，有 `serve --config` 的工作台会扫描该公共配置目录；CLI 同时查找 PSD 旁边的 `fonts/` 与系统字体。只匹配真实 PostScript 字体名，不猜测同名字体替代品；字体不在 PSD 中自动完整嵌入，交付许可需要自行确认。

### 中间文件

- `design.json`：固定尺寸画布、稳定节点 ID、从底到顶的顺序、父局部坐标、可映射文字属性、图片与字体引用。原生 PSD layer ID 优先；缺少时使用层级路径 ID，不保证外部重排后仍能识别为同一节点。
- `assets/`、`fonts/`：页面直接使用的共享资源。按内容哈希去重，不把图片 Base64 塞进 JSON。修改资源时必须同时更新引用和哈希，缺失或哈希变化会拒绝构建。
- `psd-extra.json`：Web 未消费的已解析 PSD 属性、原始文本样式与智能对象数据引用。附加二进制按哈希保存在同一资源目录，不另复制完整 PSD。
- `index.html`、`runtime.js`：构建后的 UniFlex 页面；`__PSD_UI__.export()` 返回当前中间设计数据，`inspect()` 用于检查运行时节点。
- `psd-reference.png`、`preview.png`、`validation.json`：PSD 保存的合成图、真实浏览器截图与对照结果。合成图缺失或像素对照不通过时明确标记需人工核对，不冒充 Photoshop 验收。

编辑 `design.json` 后执行 `uniflex-build` 即可更新页面；保留 `roots/children` ID 关系和资源引用。稳定 ID 用于该中间工程内的编辑，不会自动恢复按钮事件、响应式布局、业务状态或数据绑定。

### 支持与降级

首版接收 8-bit RGB PSD（3/4 通道），最大 64 MiB、2000 万画布像素、1000 图层、64 层嵌套；解码像素预算 256 MiB，ZIP 通道有独立解压输出上限，RLE 逐行验证。文字优先映射为 UniFlex 文本节点；当前字体宿主要求非斜体 400/700 字重。缺字体/缺字、多样式文字、非支持字距和变形等转为图片并逐项警告，原始文字保留在补充文件。图片层直接成为图片节点；形状和智能对象暂按图像外观渲染。

蒙版等可独立合成的外观使用 psd-tools。组蒙版/效果、组内具有完整基底的普通图层剪贴组合局部栅格化为独立图片，并明确警告其子层在 Web 中不再逐层可编辑；子层元数据、文本和原始像素缓存仍在补充文件中引用共享资源。纯色外描边按扩展边界渲染，包括嵌套组；空图层保留为透明节点。跨组背景依赖混合、非正常混合的效果、无本组基底的剪贴层、剪贴组、挖空、画板、调整层及外扩阴影/发光仍拒绝；栅格效果限纯色描边及正常混合的颜色/渐变/图案叠加。描边合成使用固定 psd-tools 1.19.0 的局部兼容适配，升级库需重验；像素对照不能替代 Photoshop 原生验收。

**这是 PSD → 中间设计 → UniFlex 的实现，不是任意 PSD 无损往返。** 补充文件目前只保存 ag-psd 已解析的数据，并未实现原始未知块的完整保留或补充数据回灌导出。已有网页 → PSD 命令仍可转换生成页面，但不自动还原智能对象内部结构等补充信息。原始 PSD 在完整往返验收前仍应保留。

生成页面的 URL 可以粘贴到“网页导出”继续转换 PSD，选择该设计的画布尺寸，并清空不同源的公共配置。工作台仅允许采集已完成的生成页面，不允许采集自己的操作界面。该路径重新采集 UniFlex 展示节点，因此 PSD 分组结构不承诺与原文件相同。

## Octane 工作流与 CLI

先在 `/Volumes/wx/src/octane-lite` 运行 `npm run dev`。本次接入只为开发页增加 `__LITE__.exportRequest()`，原生工作台按钮也复用它。未更新或生产静态页面没有该接口；源码更新后需重启开发服务。

```bash
node bin/cli.mjs octane-export --url http://127.0.0.1:4318/ \
  --out output/octane-export

# 只解析、预览，不提交
node bin/cli.mjs octane-import --url http://127.0.0.1:4318/ \
  --file output/octane-export/octane.psd --out output/octane-import

# 明确提交选中的变更
node bin/cli.mjs octane-apply --url http://127.0.0.1:4318/ \
  --report output/octane-import/import-report.json \
  --selection selection.json --out output/octane-applied
```

`selection.json` 使用导入报告中的变更 ID：

```json
{
  "selected": ["demo/daily/title#color"],
  "acceptedConflicts": [],
  "acknowledged": []
}
```

示例 ID 不表示当前文件存在该修改。冲突 ID 需另放入 `acceptedConflicts`，报告要求的确认 ID 需放入 `acknowledged`。Octane 报告在服务器内保存约 15 分钟；过期或服务重启后需要重新导入。提交失败后先核对工程 revision，网络中断不保证服务端未提交。

原生导出保留 Octane 的文字框、智能对象和基线标识，附带项目字体、预览和快照。**工具使用新的隔离浏览器会话，不继承另一个已打开 Octane 标签页的计数/显隐状态。** 要导出手动操作后的状态，仍使用原 Octane 工作台的导出按钮，再在这里上传进行差异处理。

原生预览沿用 Octane 的 Canvas 渲染，不能将其视为任意网页模式的独立逐像素验收；现有换行/Photoshop 原生重绘边界不因增加操作页面而消失。

## 推荐流程：公共分析 → 具体页面导出

```bash
# 1. 从站点入口提取公共信息，生成可复用配置
node bin/cli.mjs analyze \
  --url http://10.0.0.105:5173/ \
  --out output/common-config

# 2. 读取具体页面的当前状态，再计算分层、生成 PSD
node bin/cli.mjs export \
  --config output/common-config/config.json \
  --url http://10.0.0.105:5173/ \
  --out output/login-psd
```

其他页面使用同一份 `--config`，更换 `--url` 和 `--out` 即可，**不需要预先登记页面**。目标 URL 必须同源，路径、查询参数和 hash 可以不同。

### analyze 做什么

- 仅打开指定入口，不遍历链接、不枚举站点路由。
- 提取当前加载的字体、图片、外部样式表资源映射，以及适配器提示和通用采集参数。
- 提前处理字体：解压 WOFF/WOFF2、必要的字体名称修正、字体元数据与字形覆盖信息。
- 输出 v4 公共配置和 `cache/`；**没有页面坐标、图层、页面截图或页面快照**。
- 只能收集入口实际加载的资源，不宣称获得全站所有公共资源。

### export 做什么

- 实时访问 `--url`，此时才获取页面布局、文字、层级与图层像素。
- 根据字体真实文件哈希、字重和处理参数复用公共字体缓存。
- 目标页新增的字体或同 URL 下已更新的字体，现场处理，不误用旧字体。
- 写入 PSD、验证视觉差异、打包该页的美术交付物。

**公共配置导出始终读取当前页面，不需要 `--refresh`，也不能离线生成尚未采集的页面。** 浏览器仍会读取当前图片、样式和字体资源，以保证新鲜度；当前加速主要来自复用字体处理结果，不是跳过网页加载或页面分层。报告的 `commonResourceReuse` 给出复用和新处理字体数量。

`config.json` 与 `cache/` 应一起保留或搬迁。导出不会修改原公共缓存，新增字体会随该次页面产物交付；更新公共缓存可重新 `analyze`。`--out` 必须是不存在的新目录，且不能与公共配置目录互相嵌套。

## 配置结构

- `site`：入口、同源范围和分析时间；入口不是导出目标页。
- `defaults`：视口、适配器模式、等待时长、浏览器和字体处理设置；可修改或通过 CLI 覆盖，不绑定某页布局。
- `hints.detectedAdapter`：入口检测结果，仅提示；默认仍逐页自动判断适配器。
- `fonts` / `resources`：公共信息清单，不是布局或图层编辑源。
- `export.documentName`：PSD 文件名，不含扩展名，只允许字母、数字、点、下划线、短横线。
- `export.maxMeanError` / `maxDifferentPixelPercent`：视觉验收阈值，默认均为 5。
- `cache`：缓存位置与完整性校验；不要手改缓存元数据或字体文件。

默认视口为 750 × 1334、DPR 1。可加 `--width 1440 --height 900 --selector '#app'`。未指定根选择器时，UniFlex 使用 `#stage`，普通 DOM 使用 `html`。分析命令的 `--selector` / `--ready-selector` 仅用于入口，不写入公共默认项；具体页面需要时在导出命令单独指定。

## 一步导出及旧快照兼容

只转换一次可以直接传 URL，不必先分析：

```bash
node bin/cli.mjs export --url http://10.0.0.105:5173/ --out output/direct-001
```

需要离线重建特定页面时，保留原单页快照模式：

```bash
# 单页布局/图层快照和 v2 配置，与公共 analyze 不同
node bin/cli.mjs analyze-page --url http://10.0.0.105:5173/ --out output/page-config
node bin/cli.mjs export --config output/page-config/config.json --out output/page-psd

# v2 快照需要明确刷新，v4 公共配置不需要
node bin/cli.mjs export --config output/page-config/config.json --refresh --out output/page-updated

# 只采集、离线重建、独立验证
node bin/cli.mjs capture --url http://10.0.0.105:5173/ --out output/snapshot-001
node bin/cli.mjs build --snapshot output/snapshot-001 --out output/rebuild-001
node bin/cli.mjs verify --out output/rebuild-001
```

v2 配置绑定分析时的页面状态；改 URL/视口等采集参数需刷新或重新采集。仅此模式支持 `export.layerNames` 按快照图层 ID 离线改名。已有 v2 配置继续可用；过渡开发中的 v3 站点遍历配置已停用，应重新生成 v4 公共配置。

旧 UniFlex 本地资源模式仍兼容，但不是必需：

```bash
node bin/cli.mjs export --config examples/uniflex-login.json \
  --url http://10.0.0.105:5173/ \
  --resource-root /Volumes/wx/client/pinball/frontend/game/resources \
  --out output/local-001

npm test
node bin/cli.mjs --help
```

`examples/uniflex-login.json` 是旧手写项目适配配置，指定了本地字体清单、许可文件与原素材，所以依赖 `--resource-root`。新公共分析及 URL-only 导出均不需要该参数。

## 字体与交付

PSD 输出包含 `web-ui.psd`（或配置文件名）、`handoff.zip`、字体、独立图层 PNG、网页截图、采集快照和验证记录。文字使用真实 PSD Type 层并附字形缓存，不是将文字截图命名成文字层。普通多行 DOM 文字按行/字体拆层，不承诺还原为一个自动换行段落。

支持已加载的 TTF/OTF/WOFF/WOFF2、JS `FontFace` 字体，以及能够定位到本机文件的系统字体。仅修改交付副本，不改源字体。系统字体扫描已在 macOS 验证，其他平台未实测。

打开 PSD 前应安装随包字体。**抓到字体不代表有权分发。** 交付前检查 `fonts/LICENSE.txt` 和原许可；仅对允许修改和分发的字体使用重命名和随包交付。

## 边界与验证

- UniFlex 支持 Canvas/语义 span 文字与原生文字描边；普通 DOM 支持常规文字、图片、背景、渐变、边框、圆角外观、阴影及分组透明度。
- 外观元素为独立位图层，不承诺全矢量。普通 SVG/Canvas 内部无语义的文字仍是位图，会记录警告。
- 旋转/缩放、复杂滤镜/遮罩/混合、圆角裁剪、生成式伪元素文字、Shadow DOM/iframe、竖排/RTL、复杂文字装饰，以及零尺寸容器内的可见内容，可能在具体页面导出时明确拒绝。
- 使用独立浏览器会话，不读用户 Chrome 登录态，不自动登录/点击/提交表单。输入值默认清空。需要交互才能出现的同 URL 界面需专用状态适配器。
- 导出限制为 2000 个模型节点、2000 万画布像素；不是任意网页的无损转换器。
- 使用 RGB/Alpha 像素差验收和 psd-tools 独立逐层合成；`--skip-independent` 会明确记录跳过。
- 尚未在 Photoshop 中实际改字、保存、重开；美术交付前仍需原生验收。

配置和缓存仅应来自可信来源。背景及验证记录见 Obsidian“网页UI导出可编辑文字PSD”笔记。

## 操作页面验证

`npm test` 包含 CLI、公共缓存、独立 PSD 验证、工作台接口与模拟工程回写安全测试。

启动工作台、目标网页和 Octane 开发服务后，可执行 `node scripts/workbench-smoke.mjs`。默认检查本文的登录页和本机 Octane；通过 `WORKBENCH_URL`、`WEB_URL`、`OCTANE_URL` 环境变量指定其他地址。它在页面中执行公共分析、采集、导出、下载及原生 PSD 无修改重导入，保留任务记录和 `output/workbench-qa/` 截图，不执行工程回写。

`node scripts/psd-web-smoke.mjs /path/to/artwork.psd` 验证第三模式的真实上传、转换、ZIP 下载、网页打开、节点身份及桌面/窄屏截图。工作台先通过 `--font-dir` 配置该 PSD 的原始字体。UniFlex 集成测试需要本地源码，缺省位置不存在时会明确跳过，可设置 `UNIFLEX_ROOT`。
