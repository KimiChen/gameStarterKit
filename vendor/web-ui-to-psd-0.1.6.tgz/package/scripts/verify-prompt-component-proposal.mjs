import path from 'node:path';
import assert from 'node:assert/strict';
import { parseArgs } from 'node:util';
import { readJson, writeJson, transaction } from '../lib/io.mjs';
import { baselineDigest, reconcileComponents } from '../lib/component-reconciliation.mjs';

const { values } = parseArgs({ options: { edits: { type: 'string' }, out: { type: 'string' } } });
if (!values.edits || !values.out)
  throw new Error('Usage: node scripts/verify-prompt-component-proposal.mjs --edits PROMPT_EDIT_REGRESSION_DIR --out NEW_DIR');
const root = path.resolve(values.edits);
const baseline = await readJson(path.join(root, 'before/uniflex-export-baseline.json'));
assert.deepEqual(await readJson(path.join(root, 'after/uniflex-export-baseline.json')), baseline);
// Author declarations for the frozen Prompt fixture, not general name-based inference.
for (const [id, labelId, value] of [[12, 14, '确定'], [16, 18, '取消']]) {
  assert.equal(baseline.nodes.find(node => node.id === id)?.name, 'ActionButton');
  const label = baseline.nodes.find(node => node.id === labelId);
  assert.equal(label?.parent, id);
  assert.equal(label?.value, value);
}
const contract = {
  schemaVersion: 1, kind: 'uniflex-component-declarations',
  baselineSha256: baselineDigest(baseline),
  definitions: [{ key: 'ActionButton',
    source: '/Volumes/wx/src/gameStarterKit/apps/client/src/ui-uniflex/components/button/ActionButton.tsx' }],
  instances: [
    { key: 'prompt.confirm.action', definitionKey: 'ActionButton', rootRecordId: 12 },
    { key: 'prompt.cancel.action', definitionKey: 'ActionButton', rootRecordId: 16 },
  ],
};
const before = await readJson(path.join(root, 'before/design.json'));
const after = await readJson(path.join(root, 'after/design.json'));
const report = reconcileComponents(baseline, contract, before, after);
await transaction(values.out, async output => {
  await writeJson(path.join(output, 'components.json'), contract);
  await writeJson(path.join(output, 'component-proposal.json'), report);
});
assert.equal(report.instances[0].changes.length, 0, 'Unedited confirm component changed');
assert(report.instances[1].changes.some(change => change.fields.text?.after?.value === '确定'),
  'Edited cancel text was not attributed to the declared instance');
assert(report.instances[1].changes.some(change => change.fields.worldFrame),
  'Edited cancel movement was not reported');
console.log(JSON.stringify({ output: path.resolve(values.out), status: report.status,
  instances: report.instances.map(instance => ({ key: instance.key,
    ownedLayerIds: instance.ownedLayerIds, changedLayers: instance.changes.length })),
  conflicts: report.conflicts, applied: report.applied }, null, 2));
assert(report.conflicts.every(conflict => conflict.reason === 'changed-layer-outside-declared-components'),
  'Unexpected conflict in this edit fixture');
assert(report.conflicts.length > 0, 'Undeclared parent layout changes must remain reviewable');
console.log('PASS: component attribution and explicit undeclared-layout review gate');
