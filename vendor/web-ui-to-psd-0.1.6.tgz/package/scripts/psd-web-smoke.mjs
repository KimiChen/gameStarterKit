import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';
import sharp from 'sharp';

const file = process.argv[2];
if (!file) throw new Error('Usage: node scripts/psd-web-smoke.mjs /path/to/artwork.psd');
const base = process.env.WORKBENCH_URL || 'http://127.0.0.1:4320/';
const output = path.resolve('output/psd-web-qa');
await fs.mkdir(output, { recursive: true });
const browser = await chromium.launch({ channel: 'chrome' });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(base);
  await page.waitForFunction(() => document.querySelector('#connection').textContent.includes('已连接'));
  await page.locator('#psd-tab').click();
  assert.equal(await page.locator('#url').isVisible(), false);
  const response = page.waitForResponse(r => r.url() === new URL('api/jobs', base).href && r.request().method() === 'POST');
  await page.locator('#psd-upload-file').setInputFiles(path.resolve(file));
  const posted = await response;
  assert(posted.ok(), await posted.text());
  const queued = await posted.json();
  let job;
  for (let attempt = 0; attempt < 600; attempt++) {
    job = await (await fetch(new URL(`api/jobs/${queued.id}`, base))).json();
    if (['succeeded', 'failed', 'cancelled'].includes(job.status)) break;
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  assert.equal(job.status, 'succeeded', job.logs);
  await page.waitForFunction(id => document.querySelector('#task-id').textContent === id
    && document.querySelector('#selected-status').textContent === '已完成', job.id);
  await page.locator('#preview-toggle').click();
  await page.waitForFunction(() => {
    const image = document.querySelector('#preview-image');
    return image.complete && image.naturalWidth > 0 && !image.parentElement.hidden;
  });
  for (const width of [1440, 390, 320]) {
    await page.setViewportSize({ width, height: width === 1440 ? 1000 : 844 });
    await page.screenshot({ path: path.join(output, `workbench-${width}.png`), fullPage: true });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  }
  const [download] = await Promise.all([
    page.waitForEvent('download'), page.locator('#artifacts a.zip').click(),
  ]);
  await download.saveAs(path.join(output, 'handoff.zip'));
  const [site] = await Promise.all([page.waitForEvent('popup'), page.locator('#artifacts a.web').click()]);
  site.on('pageerror', error => errors.push(error.message));
  await site.waitForFunction(() => window.__PSD_UI__?.ready || window.__PSD_UI__?.error);
  assert.equal(await site.evaluate(() => window.__PSD_UI__.error), null);
  const runtime = await site.evaluate(() => window.__PSD_UI__.export());
  assert.equal(Object.keys(runtime.nodes).length, job.layers.length);
  assert.equal(await site.locator('[data-psd-node]').count(), job.layers.length);
  for (const width of [1440, 390]) {
    await site.setViewportSize({ width, height: 1000 });
    const screenshot = path.join(output, `uniflex-${width}.png`);
    await site.screenshot({ path: screenshot, fullPage: true });
    assert.equal(await site.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
    assert((await sharp(screenshot).stats()).channels.some(channel => channel.stdev > 10));
  }
  assert.deepEqual(errors, []);
  console.log(JSON.stringify({ jobId: job.id, output: job.output, page: site.url(),
    editableTextLayers: job.result.editableTextLayers, visualVerification: job.result.visualVerification,
    screenshotDirectory: output, errors }, null, 2));
} finally {
  await browser.close();
}
