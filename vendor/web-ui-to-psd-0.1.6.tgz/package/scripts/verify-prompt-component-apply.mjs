import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { readJson, writeJson, transaction, run } from '../lib/io.mjs';
import { baselineDigest, reconcileComponents } from '../lib/component-reconciliation.mjs';
import { worldFrames } from '../lib/design-edit-check.mjs';
import { pixelDifference } from '../lib/build.mjs';

const { values } = parseArgs({ options: { edits: { type: 'string' }, out: { type: 'string' } } });
if (!values.edits || !values.out)
  throw new Error('Usage: node scripts/verify-prompt-component-apply.mjs --edits PROMPT_EDIT_DIR --out NEW_DIR');
const source = path.resolve(values.edits);
const before = await readJson(path.join(source, 'before/design.json'));
const after = await readJson(path.join(source, 'after/design.json'));
const baseline = await readJson(path.join(source, 'before/uniflex-export-baseline.json'));
assert.deepEqual(await readJson(path.join(source, 'after/uniflex-export-baseline.json')), baseline);
const contractPath = path.join(source, 'after/component-declarations.json');
const contract = await readJson(contractPath);
const proposal = reconcileComponents(baseline, contract, before, after);
const edited = proposal.instances.find(instance => instance.key === 'prompt.cancel.action');
assert(edited, 'Expected the authored Prompt cancel instance');
const label = edited.changes.find(change => change.fields.text);
assert(label, 'Expected a proposed text edit');
const all = proposal.instances.flatMap(instance => instance.changes.flatMap(change =>
  Object.keys(change.fields).map(field => `${change.id}.${field}`)));
const result = await transaction(values.out, async output => {
  const proposalPath = path.join(output, 'component-proposal.json');
  await writeJson(proposalPath, proposal);
  for (const [name, selected] of [['text-only', [`${label.id}.text`]], ['all', all]]) {
    const selectionPath = path.join(output, `${name}-selection.json`);
    await writeJson(selectionPath, { schemaVersion: 1, kind: 'uniflex-component-selection',
      approved: true, purpose: 'automated-regression-fixture-only',
      proposalSha256: baselineDigest(proposal), selected });
    await run(process.execPath, [fileURLToPath(new URL('./apply-uniflex-components.mjs', import.meta.url)),
      '--before', path.join(source, 'before'), '--after', path.join(source, 'after'),
      '--contract', contractPath, '--proposal', proposalPath, '--selection', selectionPath,
      '--out', path.join(output, name)]);
  }
  const textOnly = await readJson(path.join(output, 'text-only/design.json'));
  assert.deepEqual(worldFrames(textOnly), worldFrames(before), 'Text-only selection moved layout');
  for (const id of Object.keys(before.nodes)) {
    const expected = structuredClone(before.nodes[id]);
    if (id === label.id) expected.text = after.nodes[id].text;
    assert.deepEqual(textOnly.nodes[id], expected, `Unexpected text-only change: ${id}`);
  }
  const full = await readJson(path.join(output, 'all/design.json'));
  assert.deepEqual(full.nodes, after.nodes, 'Full selection differs from imported edited nodes');
  const fullPixels = await pixelDifference(path.join(output, 'all/preview.png'), path.join(source, 'after/preview.png'));
  assert.equal(fullPixels.meanAbsoluteRgbError, 0);
  assert.equal(fullPixels.meanAbsoluteAlphaError, 0);
  // Applications must leave their original input files untouched.
  assert.deepEqual(await readJson(path.join(source, 'before/design.json')), before);
  assert.deepEqual(await readJson(path.join(source, 'after/design.json')), after);
  const report = { kind: 'prompt-component-apply-regression', passed: true,
    textOnlyKeepsAllFrames: true, unselectedNodesUnchanged: true,
    fullSelectionMatchesImportedProposal: true, fullSelectionPixelDifference: fullPixels,
    inputsUnchanged: true, selectionPurpose: 'automated-regression-fixture-only',
    projectSourceModified: false, businessBindingsRestored: false, editedVisualGoldenVerified: false };
  await writeJson(path.join(output, 'apply-validation.json'), report);
  return report;
});
console.log(JSON.stringify({ output: path.resolve(values.out), ...result }, null, 2));
