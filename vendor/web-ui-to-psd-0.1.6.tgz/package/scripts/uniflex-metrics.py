"""Extract UniFlex metrics from the exact exported font, without modifying it."""
import json
import sys
from fontTools.ttLib import TTFont


def extract(request):
    with TTFont(request["file"]) as font:
        if "fvar" in font:
            raise ValueError(f'{request["id"]}: instantiate variable fonts before rendering')
        cmap = font.getBestCmap() or {}
        characters = sorted(set(request["characters"]))
        missing = [char for char in characters if ord(char) not in cmap]
        if missing:
            points = ", ".join(f"U+{ord(char):04X}" for char in missing[:20])
            raise ValueError(f'{request["id"]}: missing glyphs {points}')
        return {
            "unitsPerEm": font["head"].unitsPerEm,
            "ascender": font["hhea"].ascent,
            "descender": font["hhea"].descent,
            "lineGap": font["hhea"].lineGap,
            "advances": {
                char: font["hmtx"][cmap[ord(char)]][0] for char in characters
            },
        }


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as source:
        requests = json.load(source)
    result = {request["id"]: extract(request) for request in requests}
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, ensure_ascii=False, indent=2)
        destination.write("\n")
