import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { parseArgs } from 'node:util';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import sharp from 'sharp';
import { collectUniFlex } from '../lib/capture.mjs';
import { build, flatten, pixelDifference } from '../lib/build.mjs';
import { importPsd } from '../lib/psd-import.mjs';
import { buildUniflex } from '../lib/uniflex.mjs';
import { verifyWeb } from '../lib/web-preview.mjs';
import { transaction, writeJson, readJson, run } from '../lib/io.mjs';

// A real-page regression fixture, not an export adapter or full-page acceptance.
const { values } = parseArgs({ options: {
  url: { type: 'string' }, out: { type: 'string' }, fonts: { type: 'string' },
} });
for (const key of ['url', 'out', 'fonts']) assert(values[key], `--${key} is required`);
const report = await transaction(values.out, async output => {
  const fontsRoot = path.resolve(values.fonts);
  const fonts = await readJson(path.join(fontsRoot, 'manifest.json'));
  await fs.cp(fontsRoot, path.join(output, 'fonts'), { recursive: true });
  const browser = await chromium.launch({ channel: 'chrome' });
  try {
    const page = await browser.newPage({ viewport: { width: 750, height: 1334 } });
    await page.goto(values.url);
    await page.waitForSelector('html[data-uniflex-ready=true]');
    await page.screenshot({ path: path.join(output, 'original-mail.png') });
    await page.evaluate(() => {
      const buttons = [...document.querySelectorAll('#ui [data-name=ActionButton]')];
      if (buttons.length !== 2) throw new Error('Expected two Mail ActionButtons');
      const parent = buttons[0].parentElement.parentElement;
      if (parent !== buttons[1].parentElement.parentElement) throw new Error('Button ownership changed');
      for (const child of parent.children) {
        if (child.getBoundingClientRect().top < 1225) child.style.display = 'none';
      }
    });
    const model = await page.evaluate(collectUniFlex, { selector: '#ui', fonts, groupNames: {} });
    model.documentName = 'mail-buttons'; model.fonts = fonts;
    await fs.mkdir(path.join(output, 'layers'));
    for (const item of flatten(model.children)) {
      for (const [key, fileKey] of [['png', 'file'], ['previewPng', 'previewFile']]) {
        if (!item[key]) continue;
        item[fileKey] = `layers/${item.id}-${key}.png`;
        await fs.writeFile(path.join(output, item[fileKey]), Buffer.from(item[key].split(',')[1], 'base64'));
        delete item[key];
      }
    }
    await writeJson(path.join(output, 'capture.json'), model);
    await page.screenshot({ path: path.join(output, 'web-reference.png') });
  } finally { await browser.close(); }
  await build(output, { maxMeanError: 5, maxDifferentPixelPercent: 5 });
  await run('uv', ['run', '--with', 'psd-tools[composite]==1.19.0', '--with', 'aggdraw==1.4.1',
    'python', fileURLToPath(new URL('./verify.py', import.meta.url)), output]);
  const web = path.join(output, 'web');
  await fs.mkdir(web);
  await importPsd({ file: path.join(output, 'mail-buttons.psd'), fontDir: path.join(output, 'fonts') }, web);
  await buildUniflex({ design: path.join(web, 'design.json') }, web);
  await verifyWeb(web, { channel: 'chrome', timeout: 30000 });
  const design = await readJson(path.join(web, 'design.json'));
  const texts = Object.values(design.nodes).filter(n => n.kind === 'text');
  const crop = { left: 100, top: 1225, width: 550, height: 109 };
  const files = { source: 'original-mail.png', export: 'preview.png',
    independentPsd: 'independent-preview.png', returned: 'web/preview.png' };
  for (const [key, file] of Object.entries(files))
    await sharp(path.join(output, file)).extract(crop).toFile(path.join(output, `${key}-buttons.png`));
  const stages = {};
  for (const key of ['export', 'independentPsd', 'returned'])
    stages[key] = await pixelDifference(path.join(output, 'source-buttons.png'), path.join(output, `${key}-buttons.png`));
  const textPreserved = texts.length === 2
    && texts.map(n => n.text.value).sort().join('|') === ['删除已读', '确定'].sort().join('|');
  const result = {
    scope: 'Mail footer buttons only; reference crop is from the unmodified page. Upper content is excluded from capture.',
    fullMailVerified: false, componentDefinitionsVerified: false, photoshopEditVerified: false,
    crop, textPreserved, editableTexts: texts.map(n => n.text), stages,
    passed: textPreserved && Object.values(stages).every(d =>
      d.differentPixelPercent <= 5 && d.meanAbsoluteRgbError <= 5 && d.meanAbsoluteAlphaError <= 5),
  };
  await writeJson(path.join(output, 'region-validation.json'), result);
  return result;
});
console.log(JSON.stringify({ output: path.resolve(values.out), ...report }, null, 2));
if (!report.passed) process.exitCode = 1;
