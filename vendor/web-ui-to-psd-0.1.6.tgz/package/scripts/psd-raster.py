"""Render explicitly selected isolated layers; never flatten the complete UI silently."""
import argparse
import json
from importlib.metadata import version
from pathlib import Path
import numpy as np
from psd_tools import PSDImage
import importlib

compositor = importlib.import_module("psd_tools.composite.composite")
if version("psd-tools") != "1.19.0":
    raise RuntimeError("Expanded stroke adapter requires psd-tools 1.19.0")


def expanded_stroke(self, layer, shape, alpha):
    # Upstream 1.19 crops effects to layer.bbox, discarding outside strokes.
    # Keep its stroke engine but trace in the bounded, padded render viewport.
    for effect in compositor._styled(layer.effects.find("stroke")):
        if not isinstance(shape, np.ndarray):
            shape = np.broadcast_to(np.float32(shape), (self.height, self.width, 1))
        color, stroke_shape = compositor.draw_stroke_effect(
            self._viewport, shape, effect.value, layer._psd
        )
        _, opacity = self._get_const(layer)
        self._apply_source(
            color, stroke_shape, stroke_shape * effect.opacity / 100.0 * opacity,
            effect.blend_mode,
        )


compositor.Compositor._apply_stroke_effect = expanded_stroke
original_get_group = compositor.Compositor._get_group
group_bounds = {}


def expanded_group(self, layer, knockout):
    # Only expand the child compositing viewport; overlays/masks keep source coordinates.
    previous = layer._bbox
    try:
        if id(layer) in group_bounds:
            layer._bbox = group_bounds[id(layer)]
        return original_get_group(self, layer, knockout)
    finally:
        layer._bbox = previous


compositor.Compositor._get_group = expanded_group

parser = argparse.ArgumentParser()
parser.add_argument("psd")
parser.add_argument("request")
parser.add_argument("output")
args = parser.parse_args()
request = json.loads(Path(args.request).read_text())
root = Path(args.output)
root.mkdir(parents=True, exist_ok=True)
psd = PSDImage.open(args.psd)
for entry in request:
    group_bounds.clear()
    for group in entry.get("groups", []):
        target = psd
        for index in group["indices"]:
            target = list(target)[index]
        group_bounds[id(target)] = tuple(group["viewport"])
    layer = psd
    for index in entry["indices"]:
        layer = list(layer)[index]
    if layer.name != entry["name"]:
        raise ValueError("PSD readers disagree on layer order")
    # Opacity belongs to the UI node, not to the cached RGBA resource.
    old_opacity = layer.opacity
    ancestors = []
    parent = layer
    while parent is not psd:
        ancestors.append((parent, parent.visible))
        parent = parent.parent
    try:
        layer.opacity = 255
        for parent, _ in ancestors:
            parent.visible = True
        image = layer.composite(viewport=tuple(entry["viewport"]), force=True, apply_icc=False)
    finally:
        layer.opacity = old_opacity
        for parent, visible in ancestors:
            parent.visible = visible
    if image is None:
        raise ValueError("Layer has no renderable pixels: " + entry["name"])
    image.convert("RGBA").save(root / (entry["id"] + ".png"))
