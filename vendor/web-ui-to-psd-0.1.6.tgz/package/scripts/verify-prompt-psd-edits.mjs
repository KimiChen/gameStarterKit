import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { parseArgs } from 'node:util';
import { createCanvas } from '@napi-rs/canvas';
import sharp from 'sharp';
import { initializeCanvas, readPsd, writePsdBuffer } from 'ag-psd';
import { transaction, sourceFile, readJson, writeJson } from '../lib/io.mjs';
import { flatten, pixelDifference } from '../lib/build.mjs';
import { importPsd } from '../lib/psd-import.mjs';
import { buildUniflex } from '../lib/uniflex.mjs';
import { verifyWeb } from '../lib/web-preview.mjs';
import { decodeUniFlexMetadata } from '../lib/uniflex-metadata.mjs';
import { checkDesignEdits, worldFrames } from '../lib/design-edit-check.mjs';

initializeCanvas(createCanvas);
const { values } = parseArgs({ options: { export: { type: 'string' }, out: { type: 'string' } } });
if (!values.export || !values.out)
  throw new Error('Usage: node scripts/verify-prompt-psd-edits.mjs --export PROMPT_EXPORT_DIR --out NEW_DIR');
const source = path.resolve(values.export);
const validation = await readJson(path.join(source, 'validation.json'));
assert.equal(validation.adapter, 'uniflex');
const file = await sourceFile(source, validation.psd);
const fontDir = path.join(source, 'fonts');
const report = await transaction(values.out, async directory => {
  const original = readPsd(await fs.readFile(file), { useImageData: true });
  const baseline = decodeUniFlexMetadata(original.imageResources?.xmpMetadata);
  assert(baseline?.layerMapping, 'Missing export-local layer identities');
  const buttons = flatten(original.children).filter(layer => layer.name === 'ActionButton' && layer.children);
  assert.equal(buttons.length, 2, 'This regression expects the two-button Prompt fixture');
  const target = buttons[1];
  const label = flatten(target.children).find(layer => layer.text);
  const firstLabel = flatten(buttons[0].children).find(layer => layer.text);
  assert(label && firstLabel && label.text.text !== firstLabel.text.text);
  const text = firstLabel.text.text;
  assert.equal(text.length, label.text.text.length, 'Fixture preserves text-run lengths');
  const dx = 12, dy = -8;
  const movedLayers = flatten([target]);
  for (const layer of movedLayers) {
    assert(!layer.mask && !layer.realMask && !layer.vectorMask, 'Masked edit fixture is unsupported');
    for (const [key, delta] of [['left', dx], ['right', dx], ['top', dy], ['bottom', dy]]) {
      if (Number.isFinite(layer[key])) layer[key] += delta;
    }
    if (layer.text) {
      layer.text.transform[4] += dx;
      layer.text.transform[5] += dy;
    }
  }
  label.text.text = text;
  const editedFile = path.join(directory, 'edited.psd');
  await fs.writeFile(editedFile, writePsdBuffer(original));
  const reread = readPsd(await fs.readFile(editedFile), { skipLayerImageData: true, skipCompositeImageData: true });
  assert.deepEqual(decodeUniFlexMetadata(reread.imageResources?.xmpMetadata), baseline,
    'Fixture must retain the old baseline while changing current PSD fields');
  const designs = [];
  for (const [name, input] of [['before', file], ['after', editedFile]]) {
    const output = path.join(directory, name);
    await importPsd({ file: input, fontDir }, output);
    designs.push(await readJson(path.join(output, 'design.json')));
    assert.deepEqual(await readJson(path.join(output, 'uniflex-export-baseline.json')), baseline);
    if (name === 'after') {
      // ag-psd does not redraw Type caches. Preserve but exclude this stale evidence.
      await fs.rename(path.join(output, 'psd-reference.png'), path.join(output, 'stale-psd-composite.png'));
    }
    await buildUniflex({ design: path.join(output, 'design.json') }, output);
    await verifyWeb(output);
  }
  const edit = { movedIds: movedLayers.map(layer => `layer-${layer.id}`),
    dx, dy, textId: `layer-${label.id}`, text };
  const fields = checkDesignEdits(designs[0], designs[1], edit);
  const change = await pixelDifference(path.join(directory, 'before/preview.png'), path.join(directory, 'after/preview.png'));
  assert(change.differentPixelPercent > 0, 'Browser output did not change');
  const firstFrame = worldFrames(designs[0]).get(`layer-${buttons[0].id}`);
  const region = { left: Math.floor(firstFrame.x), top: Math.floor(firstFrame.y),
    width: Math.ceil(firstFrame.x + firstFrame.width) - Math.floor(firstFrame.x),
    height: Math.ceil(firstFrame.y + firstFrame.height) - Math.floor(firstFrame.y) };
  const crops = await Promise.all(['before', 'after'].map(name =>
    sharp(path.join(directory, name, 'preview.png')).extract(region).ensureAlpha().raw().toBuffer()));
  assert(crops[0].equals(crops[1]), 'Unedited first button pixels changed');
  const result = { kind: 'scripted-prompt-psd-edit-regression', passed: true,
    fields, baselineUnchanged: true, browserChangedPixels: change,
    uneditedButtonPixelsIdentical: true,
    editedVisualGoldenVerified: false, photoshopEditVerified: false,
    componentDefinitionsVerified: false,
    warnings: ['Edited PSD retains stale text caches and composite; do not treat these as an edited visual golden.',
      'Checks current PSD fields and browser rendering; does not prove Photoshop editing or exact edited visual parity.'] };
  await writeJson(path.join(directory, 'edit-validation.json'), result);
  return result;
});
console.log(JSON.stringify({ output: path.resolve(values.out), ...report }, null, 2));
