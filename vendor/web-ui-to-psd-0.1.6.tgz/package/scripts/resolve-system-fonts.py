#!/usr/bin/env python3
"""Resolve PostScript names without exporting or modifying system fonts."""

import json
import logging
import os
from pathlib import Path
import sys


MAX_FILES = 5000
FONT_SUFFIXES = {".ttf", ".otf", ".ttc", ".otc"}


def font_directories():
    if sys.platform == "darwin":
        return [
            Path("/System/Library/Fonts"),
            Path("/Library/Fonts"),
            Path.home() / "Library/Fonts",
        ]
    if sys.platform.startswith("linux"):
        return [
            Path("/usr/share/fonts"),
            Path("/usr/local/share/fonts"),
            Path.home() / ".local/share/fonts",
        ]
    if sys.platform == "win32":
        return [Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"]
    return []


def font_files(roots):
    count = 0
    for root in roots:
        if root.is_symlink():
            continue
        for directory, subdirs, filenames in os.walk(root, followlinks=False):
            subdirs[:] = sorted(
                name for name in subdirs
                if not (Path(directory) / name).is_symlink()
            )
            for filename in sorted(filenames):
                path = Path(directory) / filename
                if path.suffix.lower() not in FONT_SUFFIXES:
                    continue
                if path.is_symlink() or not path.is_file():
                    continue
                if count >= MAX_FILES:
                    return
                count += 1
                yield path.absolute()
                if count >= MAX_FILES:
                    return


def inspect_face(font, path, index, pending, resolved):
    try:
        names = font["name"]
        matches = set()
        for record in names.names:
            if record.nameID == 6:
                try:
                    name = record.toUnicode()
                except Exception:
                    continue
                if name in pending:
                    matches.add(name)
        if not matches:
            return
        family = names.getBestFamilyName()
        if not family:
            return
        weight = int(font["OS/2"].usWeightClass) if "OS/2" in font else 400
        for name in matches:
            resolved[name] = {
                "postscriptName": name,
                "source": str(path),
                "index": index,
                "browserFamily": family,
                "weight": weight,
            }
            pending.remove(name)
    except Exception:
        # An unreadable face must not prevent other faces from resolving.
        return


def resolve(postscript_names, roots):
    from fontTools.ttLib import TTCollection, TTFont

    logger = logging.getLogger("fontTools")
    logger.handlers = [logging.NullHandler()]
    logger.propagate = False
    requested = list(dict.fromkeys(postscript_names))
    pending = set(requested)
    resolved = {}
    if pending:
        for path in font_files(roots):
            try:
                # Own the stream even if a malformed collection fails to open.
                with path.open("rb") as stream:
                    if path.suffix.lower() in {".ttc", ".otc"}:
                        with TTCollection(stream, lazy=True) as collection:
                            for index, font in enumerate(collection.fonts):
                                inspect_face(font, path, index, pending, resolved)
                                if not pending:
                                    break
                    else:
                        with TTFont(stream, lazy=True) as font:
                            inspect_face(font, path, 0, pending, resolved)
            except Exception:
                continue
            if not pending:
                break
    return {
        "resolved": [resolved[name] for name in requested if name in resolved],
        "missing": [name for name in requested if name in pending],
    }


def main():
    if len(sys.argv) != 3:
        print("Usage: resolve-system-fonts.py request.json result.json", file=sys.stderr)
        return 2
    try:
        request_path = Path(sys.argv[1]).resolve()
        result_path = Path(sys.argv[2]).resolve()
        roots = font_directories()
        # Never allow the result to overwrite a font or a file in a font root.
        if (
            result_path == request_path
            or result_path.suffix.lower() in FONT_SUFFIXES
            or any(
                result_path == root.resolve() or root.resolve() in result_path.parents
                for root in roots
            )
        ):
            raise ValueError
        request = json.loads(request_path.read_text(encoding="utf-8"))
        names = request.get("postscriptNames") if isinstance(request, dict) else None
        if not isinstance(names, list) or any(
            not isinstance(name, str) or not name.strip() for name in names
        ):
            raise ValueError
        result = resolve(names, roots)
        result_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return 0
    except ImportError:
        print("Required dependency: fonttools.", file=sys.stderr)
    except Exception:
        print("Unable to process font request or write result.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
