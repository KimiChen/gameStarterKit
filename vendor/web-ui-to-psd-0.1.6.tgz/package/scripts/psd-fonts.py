"""Resolve exact PSD PostScript names from supplied font directories, then system fonts."""
import argparse
import importlib.util
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("request")
parser.add_argument("output")
args = parser.parse_args()
spec = importlib.util.spec_from_file_location(
    "system_fonts", Path(__file__).with_name("resolve-system-fonts.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
request = json.loads(Path(args.request).read_text())
roots = [Path(root) for root in request.get("directories", [])]
result = module.resolve(request["postscriptNames"], roots + module.font_directories())
Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
