#!/usr/bin/env bash
set -euo pipefail

# Upload-triggered CI supplies paths; the runner mounts an existing HTTP webroot.
: "${PSD_FILE:?Set PSD_FILE to the downloaded/uploaded PSD}"
: "${CI_ARTIFACT_DIR:?Set a new private artifact directory}"
: "${PREVIEW_ROOT:?Set the mounted preview webroot}"
: "${PREVIEW_BASE_URL:?Set its HTTP(S) URL, reachable from the runner}"
: "${UNIFLEX_ROOT:?Set the installed UniFlex frontend source path}"
: "${FONT_DIR:?Set the licensed font directory}"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
args=(ci-preview --file "$PSD_FILE" --out "$CI_ARTIFACT_DIR"
  --publish-root "$PREVIEW_ROOT" --public-base-url "$PREVIEW_BASE_URL"
  --uniflex-root "$UNIFLEX_ROOT" --font-dir "$FONT_DIR")
if [[ -n "${PREVIEW_ID:-}" ]]; then args+=(--preview-id "$PREVIEW_ID"); fi
node "$SCRIPT_DIR/../bin/cli.mjs" "${args[@]}"
node -e 'const fs=require("node:fs"); const r=JSON.parse(fs.readFileSync(process.argv[1])); if(!r.urlVerified || !r.previewUrl) process.exit(1); console.log("PREVIEW_URL="+r.previewUrl)' \
  "$CI_ARTIFACT_DIR/ci-preview.json"
