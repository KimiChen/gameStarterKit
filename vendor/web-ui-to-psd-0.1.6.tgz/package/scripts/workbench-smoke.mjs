import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';
import sharp from 'sharp';

const base = process.env.WORKBENCH_URL || 'http://127.0.0.1:4320/';
const website = process.env.WEB_URL || 'http://10.0.0.105:5173/';
const octane = process.env.OCTANE_URL || 'http://127.0.0.1:4318/';
const output = path.resolve('output/workbench-qa');
await fs.mkdir(output, { recursive: true });
const browser = await chromium.launch({ channel: 'chrome' });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
async function perform(trigger) {
  const response = page.waitForResponse(res => res.url() === new URL('api/jobs', base).href
    && res.request().method() === 'POST');
  await trigger();
  const posted = await response;
  const queued = await posted.json();
  assert(posted.ok(), JSON.stringify(queued));
  let job;
  for (let attempt = 0; attempt < 600; attempt++) {
    job = await (await fetch(new URL(`api/jobs/${queued.id}`, base))).json();
    if (['succeeded', 'failed', 'cancelled'].includes(job.status)) break;
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  assert.equal(job.status, 'succeeded', job.logs);
  await page.waitForFunction(id => document.querySelector('#task-id').textContent === id
    && document.querySelector('#selected-status').textContent === '已完成', queued.id);
  return job;
}
async function screenshot(name) {
  const file = path.join(output, `${name}.png`);
  await page.screenshot({ path: file, fullPage: true });
  const stats = await sharp(file).stats();
  assert(stats.channels.some(channel => channel.stdev > 12), 'Screenshot appears blank');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'Horizontal overflow');
}
async function imageReady() {
  await page.waitForFunction(() => {
    const image = document.querySelector('#preview-image');
    return image.complete && image.naturalWidth > 0 && !image.parentElement.hidden;
  });
}
try {
  await page.goto(base);
  await page.waitForFunction(() => document.querySelector('#connection').textContent.includes('已连接'));
  await page.locator('#url').fill(website);
  await page.locator('#config').selectOption('');
  const analyzed = await perform(() => page.locator('[data-action=analyze]').click());
  assert.equal(analyzed.result.configuration.kind, 'site-resources');
  await page.locator('#config').selectOption(analyzed.id);
  const captured = await perform(() => page.locator('[data-action=capture]').click());
  assert(captured.layers.length > 0);
  await imageReady();
  const exported = await perform(() => page.locator('#web-actions button[type=submit]').click());
  assert.equal(exported.result.independentVerification.passed, true);
  assert(exported.result.textLayers > 0);
  await imageReady();
  await page.locator('#preview-toggle').click();
  await imageReady();
  await page.locator('#zoom-in').click();
  await page.locator('#zoom-fit').click();
  await screenshot('web-desktop');
  const psd = exported.artifacts.find(file => file.kind === 'psd');
  assert.equal(await page.locator('#artifacts a.psd').getAttribute('href'), new URL(psd.url, base).href);
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.locator('#artifacts a.psd').click(),
  ]);
  const downloadedPath = path.join(output, 'web.psd');
  await download.saveAs(downloadedPath);
  assert.equal((await fs.readFile(downloadedPath)).toString('ascii', 0, 4), '8BPS');
  for (const width of [390, 320]) {
    await page.setViewportSize({ width, height: 844 });
    await screenshot(`web-mobile-${width}`);
  }
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.locator('#octane-tab').click();
  await page.locator('#url').fill(octane);
  const native = await perform(() => page.locator('#octane-actions button[type=submit]').click());
  assert.equal(native.result.roundTrip, true);
  assert.equal(native.result.photoshopEditVerified, false);
  await imageReady();
  await screenshot('octane-desktop');
  const nativeFile = path.join(native.output, 'octane.psd');
  const imported = await perform(() => page.locator('#upload-file').setInputFiles(nativeFile));
  assert.equal(imported.result.errors.length, 0);
  assert.equal(imported.result.changes.length, 0);
  assert.equal(await page.locator('#apply-changes').isDisabled(), true);
  await screenshot('octane-import-desktop');
  await page.setViewportSize({ width: 390, height: 844 });
  await screenshot('octane-import-mobile');
  assert.deepEqual(errors, []);
  console.log(JSON.stringify({ analyzed: analyzed.id, captured: captured.id, exported: exported.id,
    native: native.id, imported: imported.id, textLayers: exported.result.textLayers,
    independentVerification: exported.result.independentVerification,
    nativeRevision: native.result.revision, screenshots: output, pageErrors: errors }, null, 2));
} finally {
  await browser.close();
}
