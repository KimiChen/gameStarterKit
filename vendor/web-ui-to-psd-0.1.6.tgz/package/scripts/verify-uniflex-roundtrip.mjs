// Compatibility entry: all behavior belongs to the main CLI.
import { fileURLToPath } from 'node:url';
import { run } from '../lib/io.mjs';
await run(process.execPath, [fileURLToPath(new URL('../bin/cli.mjs', import.meta.url)),
  'uniflex-verify', ...process.argv.slice(2)]);
