import { defineCompiledComponent, parseHostPlan } from '@uniflex/core';
import { jsonHash, sha256 } from '@uniflex/core/provider';
import { WebProvider } from '@uniflex/web';
import type { HostPlanNode, HostValue, ResourceEntry } from '@uniflex/core';

declare const __DESIGN_SHA256__: string;
declare const __READY_TIMEOUT__: number;

type DesignNode = {
  id: string; name: string; kind: 'group' | 'image' | 'text';
  frame: { x: number; y: number; width: number; height: number };
  opacity: number; visible: boolean; children?: string[]; asset?: string;
  text?: {
    value: string; fontId: string; size: number; lineHeight: number;
    align: 'left' | 'center' | 'right'; color: string;
    outlineWidth: number; outlineColor: string; wrap: boolean;
    fauxBold?: boolean;
  };
};
type Design = {
  canvas: { width: number; height: number }; roots: string[];
  nodes: Record<string, DesignNode>;
  assets: Record<string, { path: string; sha256: string; width: number; height: number }>;
  fonts: Record<string, {
    path: string; sha256: string; weight: 400 | 700;
    metrics: Extract<ResourceEntry, { kind: 'font' }>['metrics'];
  }>;
};

let design: Design | undefined;
let provider: WebProvider | undefined;
let disposed = false;
let timer: ReturnType<typeof setTimeout> | undefined;
const abort = new AbortController();
function fitViewport() {
  if (!design) return;
  const scale = Math.min(1, innerWidth / design.canvas.width);
  const stage = document.getElementById('stage')!;
  const viewport = document.getElementById('viewport')!;
  stage.style.transform = `scale(${scale})`;
  viewport.style.width = `${design.canvas.width * scale}px`;
  viewport.style.height = `${design.canvas.height * scale}px`;
}
const hook = {
  ready: false,
  error: null as { message: string } | null,
  export: () => {
    if (!design) throw new Error('Design is not loaded.');
    return structuredClone(design);
  },
  inspect: () => provider?.inspect() ?? [],
  dispose: () => {
    if (disposed) return;
    disposed = true;
    hook.ready = false;
    delete document.documentElement.dataset.uniflexReady;
    clearTimeout(timer);
    abort.abort();
    provider?.dispose();
    removeEventListener('pagehide', hook.dispose);
    removeEventListener('resize', fitViewport);
  },
};
(window as typeof window & { __PSD_UI__: typeof hook }).__PSD_UI__ = hook;
addEventListener('pagehide', hook.dispose, { once: true });

function fail(error: unknown) {
  if (disposed) return;
  hook.error = { message: error instanceof Error ? error.message : String(error) };
  hook.dispose();
  console.error('[PSD UniFlex]', hook.error.message);
}

async function start() {
  const response = await fetch(new URL('./design.json', import.meta.url), { signal: abort.signal });
  if (!response.ok) throw new Error(`design.json: HTTP ${response.status}`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (sha256(bytes) !== __DESIGN_SHA256__) throw new Error('design.json changed; rebuild the runtime.');
  design = JSON.parse(new TextDecoder().decode(bytes));
  fitViewport();
  addEventListener('resize', fitViewport);
  const documentDesign = design!;
  const ids = new Map<number, string>();
  const usedImages = new Set<string>();
  const usedFonts = new Set<string>();
  let planId = 1;
  function node(id: string): HostPlanNode {
    const value = documentDesign.nodes[id];
    const currentId = ++planId;
    ids.set(currentId, id);
    const { x, y, width, height } = value.frame;
    const props: Record<string, HostValue> = {
      name: value.name, opacity: value.opacity, visible: value.visible,
      style: { position: 'absolute', left: x, top: y, width, height },
    };
    if (value.kind === 'image') {
      usedImages.add(value.asset!);
      props.source = { kind: 'image', id: `image:${value.asset}` };
      props.sizeMode = 'simple';
    } else if (value.kind === 'text') {
      const text = value.text!;
      usedFonts.add(text.fontId);
      Object.assign(props, {
        value: text.value, font: { kind: 'font', id: `font:${text.fontId}`,
          weight: documentDesign.fonts[text.fontId].weight },
        fontSize: text.size, lineHeight: text.lineHeight, color: text.color,
        horizontalAlign: text.align, verticalAlign: 'top',
        outlineWidth: text.outlineWidth, outlineColor: text.outlineColor,
        wrap: text.wrap, overflow: 'clamp',
        ...(text.fauxBold ? { bold: true } : {}),
      });
    }
    return {
      planId: currentId, kind: value.kind === 'group' ? 'view' : value.kind, props,
      ...(value.kind === 'group' ? { children: value.children!.map(node) } : {}),
    };
  }
  const planData = {
    name: 'ImportedPSD', slotCount: 0,
    root: { planId: 1, kind: 'view',
      props: { style: { width: documentDesign.canvas.width, height: documentDesign.canvas.height } },
      children: documentDesign.roots.map(node) },
  };
  let plan;
  try {
    plan = parseHostPlan({ ...planData, version: 5 });
  } catch (error) {
    // Only the known version rejection permits fallback; invalid plans must fail.
    if (!(error instanceof Error) || error.message !== 'Unsupported HostPlan version: 5') throw error;
    plan = parseHostPlan({ ...planData, version: 2 });
  }
  const resources: ResourceEntry[] = [
    ...[...usedImages].map(id => {
      const asset = documentDesign.assets[id];
      return { id: `image:${id}`, kind: 'image' as const, file: asset.path,
        width: asset.width, height: asset.height, sha256: asset.sha256 };
    }),
    ...[...usedFonts].map(id => {
      const font = documentDesign.fonts[id];
      return { id: `font:${id}`, kind: 'font' as const, file: font.path,
        weight: font.weight, sha256: font.sha256, metrics: font.metrics };
    }),
  ];
  const mapping = Object.fromEntries(resources.map(entry => [entry.id, {
    url: new URL(entry.file, import.meta.url).href, sha256: entry.sha256,
  }]));
  provider = new WebProvider({
    container: document.getElementById('stage')!, resources: mapping,
    width: documentDesign.canvas.width, height: documentDesign.canvas.height,
  });
  await provider.assets.prepare({ version: 1, hash: jsonHash(resources), resources });
  if (disposed) return;
  const mounted = provider.mount(defineCompiledComponent(plan, () => {}), {});
  // Attach QA identity to the real Host element; never write its geometry.
  for (const element of document.querySelectorAll<HTMLElement>('#stage [data-plan-id]')) {
    const id = ids.get(Number(element.dataset.planId));
    if (id) element.dataset.psdNode = id;
  }
  await provider.compositor.present([{
    surface: mounted.surface, activity: 'active',
    presentation: { coverage: 'opaque', backdrop: 'none', blockInputBelow: false, transition: 'none' },
  }]);
  if (disposed) return;
  mounted.flushNow();
  await document.fonts.ready;
  await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  if (disposed) return;
  // Props alone do not prove support: older runtimes accept bold but ignore it.
  for (const [id, value] of Object.entries(documentDesign.nodes)) {
    if (value.kind !== 'text' || !value.text?.fauxBold || !value.visible || !value.text.value) continue;
    const element = [...document.querySelectorAll<HTMLElement>('[data-psd-node]')]
      .find(element => element.dataset.psdNode === id);
    if (!element || !element.getClientRects().length) continue;
    const canvas = element.querySelector<HTMLCanvasElement>(':scope > canvas');
    const prefix = canvas?.getContext('2d')?.font.split(/[\d.]+px/)[0] ?? '';
    const token = prefix.match(/\b([1-9]\d{0,2}|1000|bold)\b/)?.[1];
    if (token !== 'bold' && Number(token) !== 700)
      throw new Error(`${id}: runtime did not render editable fauxBold; select a UniFlex runtime with bold support.`);
  }
  clearTimeout(timer);
  hook.ready = true;
  document.documentElement.dataset.uniflexReady = 'true';
}

timer = setTimeout(() => fail(new Error(`UniFlex readiness exceeded ${__READY_TIMEOUT__}ms.`)), __READY_TIMEOUT__);
void start().catch(fail);
