# @uniflex/tooling

External-consumer tooling for UniFlex UI authoring. The package intentionally
does not depend on `@uniflex/game`, `@uniflex/shared`, or any launcher.

Create `uniflex.ui.json` in the consumer project:

```json
{
    "root": ".",
    "project": "tsconfig.ui.json",
    "input": "src/ui",
    "output": ".cache/uniflex/aot",
    "bindingsOutput": ".cache/uniflex"
}
```

Run `uniflex-ui build` or `uniflex-ui check`. The native compiler is resolved
from `compiler` in the config, `UNIFLEX_COMPILER`, or `PATH`, in that order.
This keeps the consumer project independent from the UniFlex repository path.
