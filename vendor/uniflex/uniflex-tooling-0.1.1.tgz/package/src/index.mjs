import { spawnSync } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const DEFAULTS = Object.freeze({
    input: 'src',
    output: '.cache/aot',
    bindingsOutput: '.cache',
});

export async function readUIConfig(configFile) {
    const file = resolve(configFile);
    const value = JSON.parse(await readFile(file, 'utf8'));
    return normalizeUIConfig(value, file);
}

export function normalizeUIConfig(value, configFile = 'uniflex.ui.json') {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new TypeError(`${configFile}: expected a JSON object`);
    const root = requiredString(value.root, `${configFile}.root`);
    const project = requiredString(value.project, `${configFile}.project`);
    return {
        compiler: value.compiler ? String(value.compiler) : undefined,
        root: resolve(root),
        project: resolve(root, project),
        input: String(value.input ?? DEFAULTS.input),
        output: String(value.output ?? DEFAULTS.output),
        bindingsOutput: String(value.bindingsOutput ?? DEFAULTS.bindingsOutput),
        check: Boolean(value.check),
    };
}

export function runAot(config, { check = config.check ?? false, env = process.env } = {}) {
    const executable = config.compiler || env.UNIFLEX_COMPILER || 'uniflex-compiler';
    const args = [
        'aot',
        '--project',
        config.project,
        '--root',
        config.root,
        '--input',
        config.input,
        '--output',
        config.output,
        '--bindings-output',
        config.bindingsOutput,
    ];
    if (check) args.push('--check');
    const result = spawnSync(executable, args, {
        cwd: config.root,
        encoding: 'utf8',
        env,
    });
    if (result.error) throw result.error;
    if (result.stdout) process.stdout.write(result.stdout);
    if (result.stderr) process.stderr.write(result.stderr);
    if (result.status !== 0)
        throw new Error(`uniflex-compiler exited with status ${result.status ?? 'unknown'}.`);
    return result.stdout ? JSON.parse(result.stdout) : [];
}

function requiredString(value, name) {
    if (typeof value !== 'string' || value.length === 0) throw new TypeError(`${name} is required`);
    return value;
}

export const defaults = DEFAULTS;
