export interface UIConfig {
    compiler?: string;
    root: string;
    project: string;
    input: string;
    output: string;
    bindingsOutput: string;
    check: boolean;
}

export declare const defaults: Readonly<{
    input: 'src';
    output: '.cache/aot';
    bindingsOutput: '.cache';
}>;

export declare function readUIConfig(configFile: string): Promise<UIConfig>;
export declare function normalizeUIConfig(value: unknown, configFile?: string): UIConfig;
export declare function runAot(
    config: UIConfig,
    options?: { check?: boolean; env?: Record<string, string | undefined> },
): unknown[];
